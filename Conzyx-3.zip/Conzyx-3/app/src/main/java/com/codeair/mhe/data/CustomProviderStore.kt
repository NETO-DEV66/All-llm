package com.codeair.mhe.data

import android.content.Context
import com.codeair.mhe.model.CustomProviderConfig
import com.codeair.mhe.model.customProviderFromJson
import com.codeair.mhe.model.toJson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray

/**
 * Persists the user's custom API provider configurations.
 *
 * Each config gets its own API-key pool in [ApiKeyVault] under the vault id
 * "CUSTOM_<configId>", so [ApiKeyFailoverCoordinator] multi-key rotation works
 * per custom provider exactly like it does for DeepSeek and NVIDIA.
 */
class CustomProviderStore(context: Context) {
    private val prefs = context.getSharedPreferences("custom_providers", Context.MODE_PRIVATE)
    private val mutableConfigs = MutableStateFlow(loadAll())
    val configs: StateFlow<List<CustomProviderConfig>> = mutableConfigs.asStateFlow()

    /** Vault id for a custom provider config's key pool. */
    fun vaultIdFor(configId: String): String = "CUSTOM_$configId"

    fun getAll(): List<CustomProviderConfig> = mutableConfigs.value

    fun getById(id: String): CustomProviderConfig? = mutableConfigs.value.firstOrNull { it.id == id }

    fun getActive(): CustomProviderConfig? =
        mutableConfigs.value.firstOrNull { it.isActive } ?: mutableConfigs.value.firstOrNull()

    fun save(config: CustomProviderConfig) {
        val current = mutableConfigs.value.toMutableList()
        val index = current.indexOfFirst { it.id == config.id }
        if (index >= 0) current[index] = config else current.add(config)
        persist(current)
    }

    fun setActive(id: String): Boolean {
        val current = mutableConfigs.value
        if (current.none { it.id == id }) return false
        persist(current.map { it.copy(isActive = it.id == id) })
        return true
    }

    fun remove(vault: ApiKeyVault, id: String) {
        vault.remove(vaultIdFor(id))
        val remaining = mutableConfigs.value.filterNot { it.id == id }
        // Keep exactly one active when the active one is removed.
        val fixed = if (remaining.none { it.isActive } && remaining.isNotEmpty()) {
            remaining.mapIndexed { index, cfg -> cfg.copy(isActive = index == 0) }
        } else remaining
        persist(fixed)
    }

    /** Records auto-detected capabilities on a config. */
    fun saveDetection(
        id: String,
        supportsVision: Boolean,
        contextLimit: Int,
        note: String,
    ) {
        val current = mutableConfigs.value.toMutableList()
        val index = current.indexOfFirst { it.id == id }
        if (index < 0) return
        current[index] = current[index].copy(
            detectedSupportsVision = supportsVision,
            detectedContextLimit = contextLimit,
            detectedAtMillis = System.currentTimeMillis(),
            detectionNote = note,
        )
        persist(current)
    }

    private fun loadAll(): List<CustomProviderConfig> {
        val raw = prefs.getString("configs_json", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                runCatching { customProviderFromJson(array.getJSONObject(i)) }.getOrNull()
            }
        }.getOrDefault(emptyList())
    }

    private fun persist(configs: List<CustomProviderConfig>) {
        val array = JSONArray()
        configs.forEach { array.put(it.toJson()) }
        prefs.edit().putString("configs_json", array.toString()).commit()
        mutableConfigs.value = configs
    }

    companion object {
        /** Resolves the effective wire protocol for a custom config. */
        fun protocolFor(config: CustomProviderConfig): com.codeair.mhe.model.ProviderProtocol =
            when (config.apiType) {
                com.codeair.mhe.model.CustomApiType.OPENAI_COMPATIBLE ->
                    com.codeair.mhe.model.ProviderProtocol.OPENAI_CHAT
                com.codeair.mhe.model.CustomApiType.CLAUDE_COMPATIBLE ->
                    com.codeair.mhe.model.ProviderProtocol.ANTHROPIC_GATEWAY
            }

        /** Converts a custom config into a ProviderProfile for the runtime bridges. */
        fun toProviderProfile(config: CustomProviderConfig): com.codeair.mhe.model.ProviderProfile =
            com.codeair.mhe.model.ProviderProfile(
                kind = com.codeair.mhe.model.ProviderKind.CUSTOM,
                baseUrl = config.baseUrl.trim().trimEnd('/'),
                model = config.modelId,
                hasSecret = true,
            )
    }
}
