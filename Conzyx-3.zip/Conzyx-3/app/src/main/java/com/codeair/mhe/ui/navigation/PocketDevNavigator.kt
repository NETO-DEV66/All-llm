package com.codeair.mhe.ui.navigation

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Overlay-screen navigation state for PocketDev (Milestone 1).
 *
 * Separates UI navigation from domain operations: this class owns *which*
 * overlay screen is visible and the transitions between them, while the
 * screens themselves and the domain logic stay where they are. The navigator
 * is remembered at the top of [com.codeair.mhe.ui.PocketDevApp] and passed down;
 * domain actions (e.g. "open the App Factory") call [open] instead of
 * mutating composable-local flags.
 *
 * Only one overlay is visible at a time; opening one closes the others.
 */
class PocketDevNavigator {

    /** Which overlay screen is currently open, if any. */
    var openOverlay by mutableStateOf<OverlayScreen?>(null)
        private set

    /** Back/close handling: returns true if an overlay was open and is now closed. */
    fun goBack(): Boolean {
        return if (openOverlay != null) {
            openOverlay = null
            true
        } else {
            false
        }
    }

    fun openAppFactory() {
        openOverlay = OverlayScreen.APP_FACTORY
    }

    fun openTeamStudio() {
        openOverlay = OverlayScreen.TEAM_STUDIO
    }

    fun openCloudHybrid() {
        openOverlay = OverlayScreen.CLOUD_HYBRID
    }

    fun openMarketplace() {
        openOverlay = OverlayScreen.MARKETPLACE
    }

    fun openPenTesting() {
        openOverlay = OverlayScreen.PEN_TESTING
    }

    fun openDiagnostics() {
        openOverlay = OverlayScreen.DIAGNOSTICS
    }

    fun openAllProjects() {
        openOverlay = OverlayScreen.ALL_PROJECTS
    }

    fun closeOverlay() {
        openOverlay = null
    }

    // Backward-compatible flag views for existing call sites during migration.
    val showAppFactoryScreen: Boolean get() = openOverlay == OverlayScreen.APP_FACTORY
    val showTeamStudioScreen: Boolean get() = openOverlay == OverlayScreen.TEAM_STUDIO
    val showCloudHybridScreen: Boolean get() = openOverlay == OverlayScreen.CLOUD_HYBRID
    val showMarketplaceScreen: Boolean get() = openOverlay == OverlayScreen.MARKETPLACE
    val showPenTestingScreen: Boolean get() = openOverlay == OverlayScreen.PEN_TESTING
    val showDiagnosticsScreen: Boolean get() = openOverlay == OverlayScreen.DIAGNOSTICS
    val showAllProjectsScreen: Boolean get() = openOverlay == OverlayScreen.ALL_PROJECTS
}

/** The full-screen overlay destinations reachable from PocketDev. */
enum class OverlayScreen {
    APP_FACTORY,
    TEAM_STUDIO,
    CLOUD_HYBRID,
    MARKETPLACE,
    PEN_TESTING,
    DIAGNOSTICS,
    ALL_PROJECTS,
}
