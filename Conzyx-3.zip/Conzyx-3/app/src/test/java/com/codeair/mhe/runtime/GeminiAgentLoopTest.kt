package com.codeair.mhe.runtime

import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiAgentLoopTest {

    private fun fakeExecutor(outputs: Map<String, String> = emptyMap()): GeminiToolExecutor =
        object : GeminiToolExecutor {
            override suspend fun execute(name: String, args: JSONObject): String =
                outputs[name] ?: "ok"
        }

    @Test
    fun `declarations list the five real tools`() {
        val declarations = geminiFunctionDeclarations()
        assertEquals(5, declarations.length())
        val names = (0 until declarations.length()).map { declarations.getJSONObject(it).getString("name") }
        assertEquals(listOf("run_shell", "read_file", "write_file", "edit_file", "list_dir"), names)
        declarations.getJSONObject(0).getJSONObject("parameters").let {
            assertEquals("object", it.getString("type"))
            assertTrue(it.getJSONArray("required").toString().contains("command"))
        }
    }

    @Test
    fun `parseAgentTurnParts extracts text and function calls`() {
        val parts = JSONArray()
            .put(JSONObject().put("text", "Let me check. "))
            .put(
                JSONObject().put(
                    "functionCall",
                    JSONObject().put("name", "list_dir").put("args", JSONObject().put("path", "")),
                ),
            )
        val turn = parseAgentTurnParts(parts)
        assertEquals("Let me check. ", turn.text)
        assertEquals(1, turn.functionCalls.size)
        assertEquals("list_dir", turn.functionCalls[0].name)
        assertEquals("", turn.functionCalls[0].args.getString("path"))
    }

    @Test
    fun `parseAgentTurnParts handles empty parts`() {
        val turn = parseAgentTurnParts(JSONArray())
        assertEquals("", turn.text)
        assertTrue(turn.functionCalls.isEmpty())
    }

    @Test
    fun `agent request body carries tools and contents`() {
        val contents = buildGeminiContents(listOf("user" to "hi"), "do it")
        val body = buildAgentRequestBody("sys", contents)
        val tools = body.getJSONArray("tools")
        assertEquals(1, tools.length())
        assertEquals(5, tools.getJSONObject(0).getJSONArray("functionDeclarations").length())
        assertEquals(2, body.getJSONArray("contents").length())
        assertEquals("sys", body.getJSONObject("system_instruction").getJSONArray("parts").getJSONObject(0).getString("text"))
    }

    @Test
    fun `model function call turn keeps call shape`() {
        val turn = buildModelFunctionCallTurn(
            listOf(GeminiFunctionCall("read_file", JSONObject().put("path", "a.txt"))),
        )
        assertEquals("model", turn.getString("role"))
        val call = turn.getJSONArray("parts").getJSONObject(0).getJSONObject("functionCall")
        assertEquals("read_file", call.getString("name"))
        assertEquals("a.txt", call.getJSONObject("args").getString("path"))
    }

    @Test
    fun `function response turn keeps output`() {
        val turn = buildFunctionResponseTurn(listOf("read_file" to "hello"))
        assertEquals("user", turn.getString("role"))
        val response = turn.getJSONArray("parts").getJSONObject(0).getJSONObject("functionResponse")
        assertEquals("read_file", response.getString("name"))
        assertEquals("hello", response.getJSONObject("response").getString("output"))
    }

    @Test
    fun `loop stops at text-only turn without touching tools`() = runBlocking {
        var toolCalls = 0
        val counting = object : GeminiToolExecutor {
            override suspend fun execute(name: String, args: JSONObject): String {
                toolCalls++
                return "ok"
            }
        }
        val loop = GeminiAgentLoop(counting)
        val result = loop.run(
            generateTurn = { _, onDelta ->
                onDelta("done")
                GeminiAgentTurn("done", emptyList())
            },
            systemPrompt = "sys",
            contents = buildGeminiContents(emptyList(), "hi"),
            onTextDelta = {},
            onToolStarted = { _, _ -> },
            onToolCompleted = { _, _ -> },
            isCancelled = { false },
        )
        assertEquals("done", result)
        assertEquals(0, toolCalls)
    }

    @Test
    fun `loop executes tools then continues with responses`() = runBlocking {
        val executor = fakeExecutor(mapOf("list_dir" to "file a.txt"))
        val loop = GeminiAgentLoop(executor)
        var turns = 0
        val bodies = mutableListOf<Int>()
        val result = loop.run(
            generateTurn = { body, _ ->
                bodies.add(body.getJSONArray("contents").length())
                turns++
                if (turns == 1) {
                    GeminiAgentTurn("", listOf(GeminiFunctionCall("list_dir", JSONObject())))
                } else {
                    GeminiAgentTurn("found it", emptyList())
                }
            },
            systemPrompt = "sys",
            contents = buildGeminiContents(emptyList(), "list files"),
            onTextDelta = {},
            onToolStarted = { _, _ -> },
            onToolCompleted = { _, _ -> },
            isCancelled = { false },
        )
        assertEquals("found it", result)
        assertEquals(2, turns)
        assertEquals(1, bodies[0])
        assertEquals(3, bodies[1])
    }

    @Test
    fun `loop respects max iterations`() = runBlocking {
        var executions = 0
        val counting = object : GeminiToolExecutor {
            override suspend fun execute(name: String, args: JSONObject): String {
                executions++
                return "ok"
            }
        }
        val loop = GeminiAgentLoop(counting, maxIterations = 3)
        loop.run(
            generateTurn = { _, _ ->
                GeminiAgentTurn("", listOf(GeminiFunctionCall("list_dir", JSONObject())))
            },
            systemPrompt = "sys",
            contents = buildGeminiContents(emptyList(), "go"),
            onTextDelta = {},
            onToolStarted = { _, _ -> },
            onToolCompleted = { _, _ -> },
            isCancelled = { false },
        )
        assertEquals(3, executions)
    }

    @Test
    fun `loop aborts when cancelled`() {
        val loop = GeminiAgentLoop(fakeExecutor())
        assertThrows(Exception::class.java) {
            runBlocking {
                loop.run(
                    generateTurn = { _, _ -> GeminiAgentTurn("", emptyList()) },
                    systemPrompt = "sys",
                    contents = buildGeminiContents(emptyList(), "hi"),
                    onTextDelta = {},
                    onToolStarted = { _, _ -> },
                    onToolCompleted = { _, _ -> },
                    isCancelled = { true },
                )
            }
        }
    }
}
